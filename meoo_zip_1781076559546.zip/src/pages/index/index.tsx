import { View, Text, Image } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useEffect, useState } from 'react';

// 豪士logo
const HAOSHI_LOGO = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915493031-豪士logo.png?auth_key=aa4d28070c6764bb603388491c6c5a0cae549d5d0454ace90bdd6505304be9d0';
// 藜麦吐司产品图
const TOAST_IMAGE = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915508830-藜麦吐司3.png?auth_key=29c66605c427fd584f1c97aa7b427adbc619c277692deeac24f2bb3e14473e5b';

const IndexPage = () => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoaded(true);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  const startGame = () => {
    Taro.navigateTo({ url: '/pages/game/index' });
  };

  return (
    <View className="min-h-screen w-full flex flex-col bg-background relative overflow-hidden">
      {/* 背景装饰 - 固定在背景层 */}
      <View className="absolute inset-0 overflow-hidden pointer-events-none">
        <View 
          className="absolute top-16 left-8 w-12 h-12 rounded-full"
          style={{ 
            background: 'linear-gradient(135deg, #FFE9C7, #E96F4D)', 
            opacity: 0.3,
            animation: 'float 3s ease-in-out infinite' 
          }}
        />
        <View 
          className="absolute top-32 right-6 w-10 h-10 rounded-full"
          style={{ 
            background: 'linear-gradient(135deg, #C7E9D0, #FFE9C7)', 
            opacity: 0.25,
            animation: 'float 4s ease-in-out infinite 0.5s' 
          }}
        />
        <View 
          className="absolute bottom-48 left-4 w-14 h-14 rounded-full"
          style={{ 
            background: 'linear-gradient(135deg, #FFC65C, #FFE9C7)', 
            opacity: 0.2,
            animation: 'float 3.5s ease-in-out infinite 1s' 
          }}
        />
        <View 
          className="absolute bottom-64 right-8 w-10 h-10 rounded-full"
          style={{ 
            background: 'linear-gradient(135deg, #E96F4D, #FFC65C)', 
            opacity: 0.25,
            animation: 'float 4.5s ease-in-out infinite 1.5s' 
          }}
        />
      </View>

      {/* 主内容区 - 使用flex布局确保不重叠 */}
      <View className="flex-1 flex flex-col items-center z-10 px-6 py-4">
        {/* Logo区域 - 顶部 放大5倍 居中在50%处 */}
        <View className="flex flex-col items-center justify-center mb-4" style={{ marginTop: '6vh' }}>
          <Image
            src={HAOSHI_LOGO}
            className="w-72 h-36 object-contain ml-48"
            mode="aspectFit"
          />
        </View>

        {/* 副标题 - 下移避免与logo重叠 */}
        <View className="mb-2 mt-2">
          <Text className="text-dark-brown text-lg font-bold tracking-wider text-center">
            藜麦吐司 · 梦幻烘焙工坊
          </Text>
        </View>

        {/* 产品展示 - 中间区域 */}
        <View className="flex items-center justify-center my-2">
          <View className="relative">
            <View 
              className="w-56 h-56 rounded-full flex items-center justify-center"
              style={{ 
                background: 'radial-gradient(circle, rgba(255,233,199,0.8) 0%, rgba(255,233,199,0) 70%)',
                animation: 'bounce-soft 2s ease-in-out infinite'
              }}
            >
              <Image
                src={TOAST_IMAGE}
                className="w-48 h-48 object-contain"
                mode="aspectFit"
              />
            </View>
            
            {/* 装饰星星 */}
            <View 
              className="absolute -top-2 right-0"
              style={{ animation: 'sparkle 1.5s ease-in-out infinite' }}
            >
              <Text className="text-gold text-xl">✨</Text>
            </View>
            <View 
              className="absolute top-8 -left-4"
              style={{ animation: 'sparkle 1.5s ease-in-out infinite 0.5s' }}
            >
              <Text className="text-gold text-lg">⭐</Text>
            </View>
          </View>
        </View>

        {/* Slogan - 产品下方 */}
        <View className="flex flex-col items-center mb-4">
          <Text
            className="text-quinoa-red text-xl font-extrabold mb-2"
            style={{
              textShadow: '2px 2px 0px rgba(255,198,92,0.5)',
              animation: 'slogan-bounce 1s ease-in-out infinite'
            }}
          >
            豪士豪士，好吃好吃
          </Text>
          <Text className="text-light-brown text-sm">
            无边吐司 · 高蛋白 · 低热量
          </Text>
        </View>

        {/* 开始按钮 - 底部区域 */}
        <View className="mb-4">
          {loaded ? (
            <View
              className="relative"
              onClick={startGame}
            >
              <View 
                className="px-10 py-3 rounded-full flex items-center justify-center"
                style={{ 
                  background: 'linear-gradient(135deg, #E96F4D, #FFC65C)',
                  boxShadow: '0 8px 20px rgba(233,111,77,0.4)',
                  animation: 'energy-pulse 2s ease-in-out infinite'
                }}
              >
                <Text className="text-white text-lg font-bold">开始烘焙</Text>
              </View>
              <View className="mt-2 text-center">
                <Text className="text-light-brown text-xs">点击变身小小烘焙师</Text>
              </View>
            </View>
          ) : (
            <View className="flex flex-col items-center">
              <View 
                className="w-10 h-10 rounded-full border-4 border-quinoa-red"
                style={{ 
                  borderTopColor: 'transparent',
                  animation: 'spin 1s linear infinite' 
                }}
              />
              <Text className="text-light-brown text-sm mt-3">正在准备原料...</Text>
            </View>
          )}
        </View>

        {/* 底部信息 */}
        <View className="flex flex-col items-center">
          <Text className="text-light-brown text-xs">透明工厂 · 品质看得见</Text>
        </View>
      </View>
    </View>
  );
};

export default IndexPage;
