export default definePageConfig({
  navigationBarTitleText: '分享工厂狂欢'
});
