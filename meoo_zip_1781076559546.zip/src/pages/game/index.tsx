import { View, Text, Image } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useState, useEffect } from 'react';

// 豪士logo
const HAOSHI_LOGO = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915493031-豪士logo.png?auth_key=aa4d28070c6764bb603388491c6c5a0cae549d5d0454ace90bdd6505304be9d0';
// 藜麦吐司
const TOAST_IMAGE = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915508830-藜麦吐司3.png?auth_key=29c66605c427fd584f1c97aa7b427adbc619c277692deeac24f2bb3e14473e5b';

interface LevelStatus {
  id: number;
  name: string;
  icon: string;
  unlocked: boolean;
  completed: boolean;
}

interface Blessing {
  id: number;
  name: string;
  content: string;
  price: number;
  icon: string;
}

const BLESSINGS: Blessing[] = [
  { id: 1, name: '祝福1', content: '吃豪士，出门遇好事！', price: 75, icon: '🍀' },
  { id: 2, name: '祝福2', content: '美味豪士，美事好事！', price: 75, icon: '😋' },
  { id: 3, name: '祝福3', content: '吃豪士，豪开心！', price: 75, icon: '😄' },
  { id: 4, name: '祝福4', content: '吃豪士，豪幸运马上降临！', price: 75, icon: '✨' },
];

const GamePage = () => {
  const [levels, setLevels] = useState<LevelStatus[]>([
    { id: 1, name: '原料引力场', icon: '🌾', unlocked: true, completed: false },
    { id: 2, name: '去边魔术秀', icon: '🔪', unlocked: false, completed: false },
    { id: 3, name: '烘焙弹跳屋', icon: '🔥', unlocked: false, completed: false },
    { id: 4, name: '分享工厂狂欢', icon: '🎉', unlocked: false, completed: false },
  ]);
  const [totalScore, setTotalScore] = useState(0);
  const [showShop, setShowShop] = useState(false);
  const [purchasedBlessings, setPurchasedBlessings] = useState<number[]>([]);

  useEffect(() => {
    const savedProgress = Taro.getStorageSync('gameProgress');
    if (savedProgress) {
      const progress = JSON.parse(savedProgress);
      setLevels(progress.levels || levels);
      setTotalScore(progress.score || 0);
      setPurchasedBlessings(progress.purchasedBlessings || []);
    }
  }, []);


  const purchaseBlessing = (blessing: Blessing) => {
    if (totalScore < blessing.price) {
      Taro.showToast({ title: '金币不足', icon: 'none' });
      return;
    }
    if (purchasedBlessings.includes(blessing.id)) {
      Taro.showToast({ title: '已兑换过该祝福', icon: 'none' });
      return;
    }

    const newScore = totalScore - blessing.price;
    const newPurchased = [...purchasedBlessings, blessing.id];
    setTotalScore(newScore);
    setPurchasedBlessings(newPurchased);

    // 保存到本地存储
    const savedProgress = Taro.getStorageSync('gameProgress');
    const progress = savedProgress ? JSON.parse(savedProgress) : {};
    progress.score = newScore;
    progress.purchasedBlessings = newPurchased;
    Taro.setStorageSync('gameProgress', JSON.stringify(progress));

    Taro.showToast({ title: `获得${blessing.name}！`, icon: 'success' });

    // 如果所有祝福都兑换完了，关闭商店
    if (newPurchased.length === BLESSINGS.length) {
      setTimeout(() => setShowShop(false), 1500);
    }
  };

  const closeShop = () => {
    setShowShop(false);
  };

  const startLevel = (levelId: number) => {
    const level = levels.find(l => l.id === levelId);
    if (!level || !level.unlocked) return;

    const levelUrls: Record<number, string> = {
      1: '/pages/level1/index',
      2: '/pages/level2/index',
      3: '/pages/level3/index',
      4: '/pages/result/index',
    };

    Taro.navigateTo({ url: levelUrls[levelId] });
  };

  const resetProgress = () => {
    Taro.removeStorageSync('gameProgress');
    setLevels([
      { id: 1, name: '原料引力场', icon: '🌾', unlocked: true, completed: false },
      { id: 2, name: '去边魔术秀', icon: '🔪', unlocked: false, completed: false },
      { id: 3, name: '烘焙弹跳屋', icon: '🔥', unlocked: false, completed: false },
      { id: 4, name: '分享工厂狂欢', icon: '🎉', unlocked: false, completed: false },
    ]);
    setTotalScore(0);
    Taro.showToast({ title: '进度已重置', icon: 'success' });
  };

  return (
    <View className="min-h-screen w-full flex flex-col bg-background">
      {/* 顶部导航 */}
      <View className="flex items-center justify-between px-4 py-3 bg-wheat-yellow">
        <View className="flex items-center">
          <Image src={HAOSHI_LOGO} className="w-24 h-12 object-contain" mode="aspectFit" />
        </View>
        <View
          className="flex items-center gap-2 px-3 py-1 rounded-full cursor-pointer"
          style={{ background: 'linear-gradient(90deg, #FFE9C7, #FFC65C)' }}
          onClick={() => setShowShop(true)}
        >
          <Text className="text-gold text-xl">🪙</Text>
          <Text className="text-dark-brown font-bold">{totalScore}</Text>
        </View>
      </View>

      {/* 标题区 */}
      <View className="flex flex-col items-center py-4">
        <Text className="text-dark-brown text-lg font-bold mb-1">藜麦吐司变身大作战</Text>
        <Text 
          className="text-quinoa-red text-base font-bold"
          style={{ animation: 'slogan-bounce 1s ease-in-out infinite' }}
        >
          豪士豪士，好吃好吃
        </Text>
      </View>

      {/* 吐司宝宝形象 */}
      <View className="flex justify-center py-2">
        <View 
          className="w-32 h-32 rounded-full flex items-center justify-center"
          style={{ 
            background: 'radial-gradient(circle, rgba(255,233,199,0.6) 0%, rgba(255,233,199,0) 70%)',
            animation: 'bounce-soft 2s ease-in-out infinite'
          }}
        >
          <Image src={TOAST_IMAGE} className="w-28 h-28 object-contain" mode="aspectFit" />
        </View>
      </View>

      {/* 关卡选择 */}
      <View className="flex-1 px-6 py-4">
        <Text className="text-dark-brown text-base font-bold mb-4 text-center">选择关卡</Text>
        
        <View className="grid grid-cols-2 gap-4">
          {levels.map((level, index) => (
            <View
              key={level.id}
              className={`relative rounded-2xl p-4 flex flex-col items-center ${
                level.unlocked ? 'cursor-pointer' : ''
              }`}
              style={{
                background: level.completed 
                  ? 'linear-gradient(135deg, #C7E9D0, #FFE9C7)'
                  : level.unlocked
                  ? 'linear-gradient(135deg, #FFE9C7, #FFC65C)'
                  : '#F5E2D1',
                boxShadow: level.unlocked ? '0 4px 12px rgba(233,111,77,0.2)' : 'none',
                opacity: level.unlocked ? 1 : 0.6,
                animation: level.unlocked && !level.completed ? 'float 3s ease-in-out infinite' : 'none',
                animationDelay: `${index * 0.2}s`
              }}
              onClick={() => startLevel(level.id)}
            >
              {/* 关卡状态标记 */}
              {level.completed && (
                <View className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-cream-green flex items-center justify-center">
                  <Text className="text-white text-xs">✓</Text>
                </View>
              )}
              {!level.unlocked && (
                <View
                  className="absolute inset-0 flex items-center justify-center rounded-2xl"
                  style={{ backgroundColor: 'rgba(0,0,0,0.1)' }}
                >
                  <Text className="text-3xl">🔒</Text>
                </View>
              )}
              
              <Text className="text-5xl mb-2">{level.icon}</Text>
              <Text className="text-dark-brown text-sm font-bold">关卡 {level.id}</Text>
              <Text className="text-light-brown text-xs">{level.name}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* 底部信息 */}
      <View className="px-6 py-4">
        <View className="flex items-center justify-center mb-4">
          <Text className="text-light-brown text-xs">全球精选原料 · 透明工厂制作</Text>
        </View>

        <View
          className="flex items-center justify-center py-2"
          onClick={resetProgress}
        >
          <Text className="text-light-brown text-xs underline">重置游戏进度</Text>
        </View>
      </View>

      {/* 商店弹窗 */}
      {showShop && (
        <View
          className="absolute inset-0 flex items-center justify-center z-50"
          style={{ backgroundColor: 'rgba(0,0,0,0.6)' }}
        >
          <View
            className="bg-white rounded-3xl p-6 flex flex-col items-center mx-4 max-w-sm"
            style={{ animation: 'pop-in 0.3s ease-out' }}
          >
            {/* 商店标题 */}
            <View className="flex items-center gap-2 mb-4">
              <Text className="text-3xl">🛒</Text>
              <Text className="text-dark-brown text-xl font-bold">豪士祝福商店</Text>
              <Text className="text-3xl">🛒</Text>
            </View>

            {/* 当前金币 */}
            <View
              className="flex items-center gap-2 px-4 py-2 rounded-full mb-4"
              style={{ background: 'linear-gradient(90deg, #FFE9C7, #FFC65C)' }}
            >
              <Text className="text-xl">🪙</Text>
              <Text className="text-dark-brown font-bold">{totalScore} 金币</Text>
            </View>

            {/* 祝福列表 */}
            <View className="w-full space-y-3 mb-4">
              {BLESSINGS.map((blessing) => {
                const isPurchased = purchasedBlessings.includes(blessing.id);
                return (
                  <View
                    key={blessing.id}
                    className={`w-full p-3 rounded-xl border-2 ${
                      isPurchased ? 'border-cream-green bg-green-50' : 'border-wheat-yellow'
                    }`}
                    style={{
                      background: isPurchased ? '#F0FDF4' : 'linear-gradient(135deg, #FFF8F0, #FFE9C7)',
                    }}
                  >
                    <View className="flex items-center justify-between">
                      <View className="flex items-center gap-2 flex-1">
                        <Text className="text-2xl">{blessing.icon}</Text>
                        <View className="flex-1">
                          <Text className="text-dark-brown font-bold text-sm">{blessing.name}</Text>
                          <Text className="text-light-brown text-xs">{blessing.content}</Text>
                        </View>
                      </View>
                      <View
                        className={`px-3 py-1 rounded-full ${
                          isPurchased
                            ? 'bg-cream-green'
                            : totalScore >= blessing.price
                            ? 'bg-quinoa-red'
                            : 'bg-gray-300'
                        }`}
                        onClick={() => !isPurchased && purchaseBlessing(blessing)}
                      >
                        <Text className="text-white text-xs font-bold">
                          {isPurchased ? '已兑换' : `${blessing.price}🪙`}
                        </Text>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>

            {/* 关闭按钮 */}
            <View
              className="px-6 py-2 rounded-full"
              style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
              onClick={closeShop}
            >
              <Text className="text-white font-bold">关闭商店</Text>
            </View>
          </View>
        </View>
      )}
    </View>
  );
};

export default GamePage;
