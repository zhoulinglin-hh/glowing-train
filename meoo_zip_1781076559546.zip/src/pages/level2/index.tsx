import { View, Text, Image } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useState, useEffect, useRef, useCallback, memo } from 'react';

// 豪士logo
const HAOSHI_LOGO = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915493031-豪士logo.png?auth_key=aa4d28070c6764bb603388491c6c5a0cae549d5d0454ace90bdd6505304be9d0';
// 藜麦吐司
const TOAST_IMAGE = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915508830-藜麦吐司3.png?auth_key=29c66605c427fd584f1c97aa7b427adbc619c277692deeac24f2bb3e14473e5b';

interface Edge {
  id: string;
  side: 'top' | 'right' | 'bottom' | 'left';
  removed: boolean;
}

const Level2Page = () => {
  const [gameState, setGameState] = useState<'ready' | 'playing' | 'completed'>('ready');
  const [score, setScore] = useState(0);
  const [edges, setEdges] = useState<Edge[]>([
    { id: 'top', side: 'top', removed: false },
    { id: 'right', side: 'right', removed: false },
    { id: 'bottom', side: 'bottom', removed: false },
    { id: 'left', side: 'left', removed: false },
  ]);
  const [showSlogan, setShowSlogan] = useState(false);
  const [particles, setParticles] = useState<{ id: number; x: number; y: number; side: string }[]>([]);
  const [toastRounded, setToastRounded] = useState(false);
  const [showEncouragement, setShowEncouragement] = useState(false);
  const [encouragementText, setEncouragementText] = useState('');
  const containerRef = useRef<any>(null);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);
  const encouragementTimerRef = useRef<NodeJS.Timeout | null>(null);

  const startGame = () => {
    setGameState('playing');
    setScore(0);
    setEdges([
      { id: 'top', side: 'top', removed: false },
      { id: 'right', side: 'right', removed: false },
      { id: 'bottom', side: 'bottom', removed: false },
      { id: 'left', side: 'left', removed: false },
    ]);
    setToastRounded(false);
    setShowEncouragement(false);
    if (encouragementTimerRef.current) {
      clearTimeout(encouragementTimerRef.current);
    }

    // 延迟500ms显示开始文案，持续4秒
    encouragementTimerRef.current = setTimeout(() => {
      setEncouragementText('每个人都有自己的喜好，长大后也可以决定自己的小生活，面包不吃硬边也可以。');
      setShowEncouragement(true);
      encouragementTimerRef.current = setTimeout(() => {
        setShowEncouragement(false);
      }, 4000);
    }, 500);
  };

  const removeEdge = (side: string) => {
    setEdges(prev => prev.map(edge => 
      edge.side === side ? { ...edge, removed: true } : edge
    ));
    
    // 添加粒子效果
    const newParticles = [...Array(8)].map((_, i) => ({
      id: Date.now() + i,
      x: 50 + (Math.random() - 0.5) * 40,
      y: 50 + (Math.random() - 0.5) * 40,
      side
    }));
    setParticles(prev => [...prev, ...newParticles]);
    
    // 清除粒子
    setTimeout(() => {
      setParticles(prev => prev.filter(p => !newParticles.find(np => np.id === p.id)));
    }, 1000);

    setScore(s => s + 25);
    
    // 检查是否全部完成
    const remaining = edges.filter(e => !e.removed && e.side !== side).length;
    if (remaining === 0) {
      // 清除之前的鼓励文案定时器
      if (encouragementTimerRef.current) {
        clearTimeout(encouragementTimerRef.current);
      }
      setShowEncouragement(false);

      setTimeout(() => {
        setToastRounded(true);
        setShowSlogan(true);
        // 显示完成时的鼓励文案在关卡标题下方
        setEncouragementText('不爱吃硬边，豪士藜麦吐司来拯救你。');
        setShowEncouragement(true);
        // 2秒后自动关闭文案并显示完成弹窗
        encouragementTimerRef.current = setTimeout(() => {
          setShowEncouragement(false);
          setGameState('completed');
          saveProgress();
        }, 2000);
      }, 500);
    }
  };

  const saveProgress = () => {
    const progress = Taro.getStorageSync('gameProgress');
    const data = progress ? JSON.parse(progress) : { levels: [], score: 0 };
    data.levels = data.levels || [];
    data.levels[1] = { id: 2, completed: true, unlocked: true };
    data.levels[2] = { id: 3, completed: false, unlocked: true };
    data.score = (data.score || 0) + score;
    Taro.setStorageSync('gameProgress', JSON.stringify(data));
  };

  const handleTouchStart = (e: any) => {
    if (gameState !== 'playing') return;
    const touch = e.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleTouchMove = useCallback((e: any) => {
    if (gameState !== 'playing' || !touchStartRef.current) return;

    const touch = e.touches[0];
    const dx = touch.clientX - touchStartRef.current.x;
    const dy = touch.clientY - touchStartRef.current.y;
    const minSwipe = 40;

    // 检测滑动方向 - 手势方向与切边方向一致
    if (Math.abs(dx) > Math.abs(dy)) {
      // 水平滑动
      if (Math.abs(dx) > minSwipe) {
        const leftEdge = edges.find(edge => edge.side === 'left');
        const rightEdge = edges.find(edge => edge.side === 'right');
        // 向左滑动切左边，向右滑动切右边
        if (dx < 0 && leftEdge && !leftEdge.removed) {
          removeEdge('left');
          touchStartRef.current = null;
        } else if (dx > 0 && rightEdge && !rightEdge.removed) {
          removeEdge('right');
          touchStartRef.current = null;
        }
      }
    } else {
      // 垂直滑动
      if (Math.abs(dy) > minSwipe) {
        const topEdge = edges.find(edge => edge.side === 'top');
        const bottomEdge = edges.find(edge => edge.side === 'bottom');
        // 向上滑动切上边，向下滑动切下边
        if (dy < 0 && topEdge && !topEdge.removed) {
          removeEdge('top');
          touchStartRef.current = null;
        } else if (dy > 0 && bottomEdge && !bottomEdge.removed) {
          removeEdge('bottom');
          touchStartRef.current = null;
        }
      }
    }
  }, [gameState, edges]);

  const handleTouchEnd = () => {
    touchStartRef.current = null;
  };

  const nextLevel = () => {
    // 关闭鼓励文案
    setShowEncouragement(false);
    Taro.redirectTo({ url: '/pages/level3/index' });
  };

  // 关闭鼓励文案
  const closeEncouragement = () => {
    setShowEncouragement(false);
    // 如果游戏已完成但未保存进度，则保存并进入完成状态
    if (toastRounded && gameState !== 'completed') {
      setGameState('completed');
      saveProgress();
    }
  };

  const backToMenu = () => {
    Taro.redirectTo({ url: '/pages/game/index' });
  };

  const getEdgeStyle = (side: string) => {
    const base = {
      position: 'absolute',
      background: 'linear-gradient(135deg, #D4A574, #8B6914)',
      borderRadius: '4px',
    } as any;
    
    switch (side) {
      case 'top':
        return { ...base, top: 0, left: 0, right: 0, height: '20px' };
      case 'bottom':
        return { ...base, bottom: 0, left: 0, right: 0, height: '20px' };
      case 'left':
        return { ...base, left: 0, top: 0, bottom: 0, width: '20px' };
      case 'right':
        return { ...base, right: 0, top: 0, bottom: 0, width: '20px' };
      default:
        return base;
    }
  };

  return (
    <View className="min-h-screen w-full flex flex-col bg-background relative overflow-hidden">
      {/* 顶部导航 */}
      <View className="flex items-center justify-between px-4 py-3 bg-wheat-yellow">
        <View className="flex items-center" onClick={backToMenu}>
          <Image src={HAOSHI_LOGO} className="w-24 h-12 object-contain" mode="aspectFit" />
        </View>
        <View className="flex items-center gap-2">
          <Text className="text-gold text-xl">🪙</Text>
          <Text className="text-dark-brown font-bold">{score}</Text>
        </View>
      </View>

      {/* 关卡标题 */}
      <View className="flex flex-col items-center py-4 bg-gradient-to-b from-wheat-yellow to-background">
        <Text className="text-dark-brown text-2xl font-bold">关卡 2</Text>
        <Text className="text-quinoa-red text-xl font-bold">去边魔术秀</Text>
        <Text className="text-light-brown text-sm mt-1">滑动切掉吐司边</Text>
      </View>

      {/* 完成鼓励文案 - 显示在关卡标题正下方，2秒后自动关闭 */}
      {showEncouragement && toastRounded && (
        <View className="px-4 pb-2" style={{ animation: 'pop-in 0.5s ease-out' }}>
          <View className="bg-white rounded-2xl p-4 shadow-lg" style={{ backgroundColor: 'rgba(255,255,255,0.95)', boxShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>
            <Text className="text-dark-brown text-sm text-center leading-relaxed">{encouragementText}</Text>
          </View>
        </View>
      )}

      {/* 游戏区域 */}
      <View 
        className="flex-1 relative flex items-center justify-center"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* 背景装饰 */}
        <View className="absolute inset-0 overflow-hidden">
          <View 
            className="absolute top-20 left-10 w-32 h-32 rounded-full opacity-10"
            style={{ background: 'radial-gradient(circle, #FFE9C7, transparent)' }}
          />
          <View 
            className="absolute bottom-20 right-10 w-40 h-40 rounded-full opacity-10"
            style={{ background: 'radial-gradient(circle, #C7E9D0, transparent)' }}
          />
        </View>

        {/* 吐司主体 */}
        <View 
          className="relative w-64 h-64 flex items-center justify-center"
          style={{ 
            transform: toastRounded ? 'scale(1.05)' : 'scale(1)',
            transition: 'transform 0.5s ease-out'
          }}
        >
          {/* 吐司边 */}
          {edges.filter(e => !e.removed).map(edge => (
            <View
              key={edge.id}
              className="flex items-center justify-center"
              style={getEdgeStyle(edge.side)}
            >
              <Text
                className="text-xs"
                style={{ color: 'rgba(255,255,255,0.5)' }}
              >
                {edge.side === 'top' || edge.side === 'bottom' ? '━━' : '┃'}
              </Text>
            </View>
          ))}
          
          {/* 吐司主体 */}
          <View 
            className="w-56 h-56 flex items-center justify-center overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #FFE9C7, #F5E2D1)',
              borderRadius: toastRounded ? '50%' : '16px',
              boxShadow: 'inset 0 2px 8px rgba(255,255,255,0.5), 0 8px 24px rgba(94,58,43,0.2)',
              transition: 'border-radius 0.5s ease-out'
            }}
          >
            <Image 
              src={TOAST_IMAGE}
              className="w-48 h-48 object-contain"
              mode="aspectFit"
              style={{
                filter: toastRounded ? 'brightness(1.1)' : 'brightness(1)',
                transition: 'filter 0.5s ease-out'
              }}
            />
          </View>

          {/* 切边提示 */}
          {gameState === 'playing' && !toastRounded && (
            <>
              {!edges.find(e => e.side === 'top')?.removed && (
                <View className="absolute -top-8 left-1/2 -translate-x-1/2">
                  <Text className="text-quinoa-red text-2xl animate-bounce">👆</Text>
                </View>
              )}
              {!edges.find(e => e.side === 'bottom')?.removed && (
                <View className="absolute -bottom-8 left-1/2 -translate-x-1/2">
                  <Text className="text-quinoa-red text-2xl animate-bounce">👇</Text>
                </View>
              )}
              {!edges.find(e => e.side === 'left')?.removed && (
                <View className="absolute top-1/2 -left-8 -translate-y-1/2">
                  <Text className="text-quinoa-red text-2xl animate-bounce">👈</Text>
                </View>
              )}
              {!edges.find(e => e.side === 'right')?.removed && (
                <View className="absolute top-1/2 -right-8 -translate-y-1/2">
                  <Text className="text-quinoa-red text-2xl animate-bounce">👉</Text>
                </View>
              )}
            </>
          )}
        </View>

        {/* 粒子效果 */}
        {particles.map(p => (
          <View
            key={p.id}
            className="absolute w-3 h-3 rounded-full"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              background: '#D4A574',
              animation: 'confetti-fall 1s ease-out forwards',
              transform: `rotate(${Math.random() * 360}deg)`
            }}
          />
        ))}

        {/* 提示文字 */}
        <View className="absolute bottom-20 left-0 right-0 text-center">
          <Text className="text-light-brown text-sm">
            {toastRounded ? '完美的无边吐司！' : '向边缘滑动切掉吐司边'}
          </Text>
        </View>

        {/* Slogan弹出 */}
        {showSlogan && (
          <View
            className="absolute top-1/3 left-0 right-0 flex flex-col items-center"
            style={{ animation: 'pop-in 0.5s ease-out' }}
          >
            <Text
              className="text-quinoa-red text-2xl font-bold mb-2"
              style={{
                textShadow: '2px 2px 4px rgba(255,198,92,0.5)',
                animation: 'slogan-bounce 1s ease-in-out infinite'
              }}
            >
              豪士豪士，好吃好吃
            </Text>
            <Text className="text-dark-brown text-base font-bold">
              无边的温柔，豪士独有！
            </Text>
          </View>
        )}

        {/* 开始遮罩 */}
        {gameState === 'ready' && (
          <View
            className="absolute inset-0 flex items-center justify-center"
            style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
          >
            <View className="bg-white rounded-3xl p-8 flex flex-col items-center">
              <Text className="text-4xl mb-4">🔪</Text>
              <Text className="text-dark-brown text-lg font-bold mb-2">去边魔术秀</Text>
              <Text className="text-light-brown text-sm mb-6 text-center">
                用手指在吐司边缘滑动{'\n'}切掉四个粗糙的吐司边{'\n'}让吐司变得圆润可爱！
              </Text>
              <View 
                className="px-8 py-3 rounded-full"
                style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
                onClick={startGame}
              >
                <Text className="text-white font-bold">开始游戏</Text>
              </View>
            </View>
          </View>
        )}

        {/* 完成遮罩 */}
        {gameState === 'completed' && (
          <View
            className="absolute inset-0 flex items-center justify-center"
            style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
          >
            <View className="bg-white rounded-3xl p-8 flex flex-col items-center">
              <Text className="text-4xl mb-4">✨</Text>
              <Text className="text-dark-brown text-lg font-bold mb-2">关卡完成！</Text>
              <Text className="text-quinoa-red text-xl font-bold mb-4">
                无边吐司制作成功
              </Text>
              <Text className="text-light-brown text-sm mb-6">
                获得 {score} 金币
              </Text>
              <View 
                className="px-8 py-3 rounded-full mb-3"
                style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
                onClick={nextLevel}
              >
                <Text className="text-white font-bold">下一关</Text>
              </View>
              <View 
                className="px-8 py-3 rounded-full bg-muted"
                onClick={backToMenu}
              >
                <Text className="text-dark-brown">返回菜单</Text>
              </View>
            </View>
          </View>
        )}
      </View>
    </View>
  );
};

export default Level2Page;
