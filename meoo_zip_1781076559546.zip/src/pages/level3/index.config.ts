export default definePageConfig({
  navigationBarTitleText: '烘焙弹跳屋'
});
